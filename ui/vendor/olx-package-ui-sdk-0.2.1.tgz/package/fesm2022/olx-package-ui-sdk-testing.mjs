import { assertAssetPath } from '@olx/package-ui-sdk/contract';

/**
 * Resolves `blob:stub/<path>` for every valid path, or the mapped URL when the path is in `urls`;
 * refuses invalid paths with the error of `assertAssetPath`, like a real Host.
 */
function createStubAssets(urls = {}) {
    const calls = [];
    return {
        calls,
        url: (path) => {
            calls.push(path);
            try {
                assertAssetPath(path);
            }
            catch (error) {
                return Promise.reject(error instanceof Error ? error : new Error(String(error)));
            }
            return Promise.resolve(urls[path] ?? `blob:stub/${path}`);
        },
    };
}

function createStubTools(handlers = {}) {
    return {
        call: (tool, input = {}) => {
            const handler = handlers[tool];
            return handler === undefined
                ? Promise.reject(new Error(`tools.call not stubbed: ${tool}`))
                : Promise.resolve(handler(input));
        },
    };
}
function createPackageContext(overrides = {}) {
    return {
        hostUiApi: '1',
        package: { name: 'letaky', version: '0.0.0-test' },
        screen: 'list',
        subPath: '',
        query: {},
        locale: 'sk',
        theme: 'light',
        user: { name: 'tester', roles: ['operator'] },
        cspNonce: 'test-nonce',
        tools: createStubTools(),
        assets: createStubAssets(),
        navigate: () => undefined,
        navigateScreen: () => undefined,
        setTitle: () => undefined,
        notify: () => undefined,
        confirm: () => Promise.resolve(true),
        refreshBadges: () => undefined,
        ...overrides,
    };
}
function isPlainObject(value) {
    const proto = Object.getPrototypeOf(value);
    return proto === Object.prototype || proto === null;
}
/**
 * Paths of members that cannot travel over postMessage: anything that is not data, a function or a
 * plain object/array. Reported members are not descended into.
 */
function findNonSerializableMembers(value, path = '') {
    if (value === null || typeof value !== 'object') {
        return [];
    }
    if (Array.isArray(value)) {
        return value.flatMap((item, index) => findNonSerializableMembers(item, join(path, String(index))));
    }
    if (!isPlainObject(value)) {
        return [path];
    }
    return Object.entries(value).flatMap(([key, member]) => findNonSerializableMembers(member, join(path, key)));
}
function join(path, key) {
    return path === '' ? key : `${path}.${key}`;
}

/**
 * Generated bundle index. Do not edit.
 */

export { createPackageContext, createStubAssets, createStubTools, findNonSerializableMembers };
//# sourceMappingURL=olx-package-ui-sdk-testing.mjs.map
