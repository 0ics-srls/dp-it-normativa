import * as i0 from '@angular/core';
import { InjectionToken, inject, Injectable, Injector, effect, CSP_NONCE, APP_ID, provideZonelessChangeDetection } from '@angular/core';
import { providePrimeNG, PrimeNG } from 'primeng/config';
import { LocationStrategy, DOCUMENT } from '@angular/common';
import { Router, provideRouter } from '@angular/router';
import Aura from '@primeng/themes/aura';
import { elementPrefix, assertPackageElementTag } from '@olx/package-ui-sdk/contract';
export { AssetPathError, InvalidElementTagError, InvalidPackageNameError, assertAssetPath, elementPrefix } from '@olx/package-ui-sdk/contract';
import { createApplication } from '@angular/platform-browser';
import { createCustomElement } from '@angular/elements';

const PACKAGE_CONTEXT = new InjectionToken('PACKAGE_CONTEXT');
class MissingPackageContextError extends Error {
    constructor() {
        super('PACKAGE_CONTEXT is not provided: add providePackageContext(forwardRef(() => YourScreen)) to the providers of the Screen root component');
        this.name = 'MissingPackageContextError';
    }
}
/** Provides the context signal of `host` (the Screen root component) to its descendants. */
function providePackageContext(host) {
    return {
        provide: PACKAGE_CONTEXT,
        useFactory: () => inject(host).context,
    };
}
function injectPackageContext() {
    const context = inject(PACKAGE_CONTEXT, { optional: true });
    if (context === null) {
        throw new MissingPackageContextError();
    }
    return context;
}

class AssetsUnavailableError extends Error {
    constructor(hostUiApi) {
        super(`The Host (hostUiApi '${hostUiApi}') does not provide context.assets: it predates contract v0.4. Update the Console or do not use assets.`);
        this.name = 'AssetsUnavailableError';
    }
}
/** The assets of the current Screen context; fails clearly on a Host that predates contract v0.4. */
function injectPackageAssets() {
    const context = injectPackageContext()();
    // The type says required; a Host built before v0.4 still omits it at runtime.
    const assets = context.assets;
    if (assets === undefined) {
        throw new AssetsUnavailableError(context.hostUiApi);
    }
    return assets;
}

/** Builds the internal URL ('/sub/path?key=value') of a Screen location. */
function toInternalUrl(location) {
    const path = '/' +
        location.subPath
            .split('/')
            .filter((segment) => segment !== '')
            .map(encodeURIComponent)
            .join('/');
    const search = Object.entries(location.query)
        .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
        .join('&');
    return search === '' ? path : `${path}?${search}`;
}
/** Parses an internal URL into a normalized location (last duplicate key wins, fragment dropped). */
function parseInternalUrl(url) {
    const withoutFragment = url.split('#', 1)[0] ?? '';
    const queryStart = withoutFragment.indexOf('?');
    const rawPath = queryStart < 0 ? withoutFragment : withoutFragment.slice(0, queryStart);
    const rawQuery = queryStart < 0 ? '' : withoutFragment.slice(queryStart + 1);
    const subPath = rawPath
        .split('/')
        .filter((segment) => segment !== '')
        .map(safeDecode)
        .join('/');
    const query = {};
    for (const [key, value] of new URLSearchParams(rawQuery)) {
        query[key] = value;
    }
    return { subPath, query };
}
/** Builds the Console URL ('/p/<package>/<screen>/...') for an internal URL. */
function toConsoleUrl(ref, internalUrl) {
    const tail = toInternalUrl(parseInternalUrl(internalUrl));
    return `/p/${encodeURIComponent(ref.package)}/${encodeURIComponent(ref.screen)}${tail === '/' ? '' : tail}`;
}
/** True when both locations have the same subPath and the same query, regardless of key order. */
function sameLocation(a, b) {
    if (a.subPath !== b.subPath) {
        return false;
    }
    const aKeys = Object.keys(a.query);
    return (aKeys.length === Object.keys(b.query).length &&
        aKeys.every((key) => Object.hasOwn(b.query, key) && a.query[key] === b.query[key]));
}
function safeDecode(segment) {
    try {
        return decodeURIComponent(segment);
    }
    catch {
        return segment;
    }
}

class PackageContextNotConnectedError extends Error {
    constructor() {
        super('Router navigation happened before the Screen received its context; call connectPackageScreen(this.context) in the root component');
        this.name = 'PackageContextNotConnectedError';
    }
}
/**
 * Angular LocationStrategy that keeps the Router's URL in the Console-provided context
 * (`subPath`/`query`) and reports navigations through `context.navigate`.
 */
class PackageLocationStrategy extends LocationStrategy {
    ref = null;
    navigator = null;
    current = { subPath: '', query: {} };
    listeners = new Set();
    /** Stores the latest context; returns true (and notifies listeners) when the location changed. */
    applyContext(context) {
        this.ref = { package: context.package.name, screen: context.screen };
        this.navigator = (subPath, query) => {
            context.navigate(subPath, query);
        };
        const next = { subPath: context.subPath, query: context.query };
        if (sameLocation(this.current, next)) {
            return false;
        }
        this.current = next;
        for (const listener of this.listeners) {
            listener({ type: 'popstate', state: null });
        }
        return true;
    }
    path() {
        return toInternalUrl(this.current);
    }
    prepareExternalUrl(internal) {
        return this.ref === null ? internal : toConsoleUrl(this.ref, internal);
    }
    pushState(_state, _title, url, queryParams) {
        this.go(url, queryParams);
    }
    replaceState(_state, _title, url, queryParams) {
        this.go(url, queryParams);
    }
    onPopState(fn) {
        this.listeners.add(fn);
        return () => {
            this.listeners.delete(fn);
        };
    }
    getBaseHref() {
        return '';
    }
    getState() {
        return null;
    }
    back() {
        window.history.back();
    }
    forward() {
        window.history.forward();
    }
    historyGo(relativePosition = 0) {
        window.history.go(relativePosition);
    }
    go(url, queryParams) {
        if (this.navigator === null) {
            throw new PackageContextNotConnectedError();
        }
        const next = parseInternalUrl(queryParams === '' ? url : `${url}?${queryParams}`);
        if (sameLocation(this.current, next)) {
            return; // the Router re-syncs its own URL (e.g. initial navigation); nothing changed for the Console
        }
        this.current = next;
        this.navigator(next.subPath, next.query);
    }
    static ɵfac = /*@__PURE__*/ (() => { let ɵPackageLocationStrategy_BaseFactory; return function PackageLocationStrategy_Factory(__ngFactoryType__) { return (ɵPackageLocationStrategy_BaseFactory || (ɵPackageLocationStrategy_BaseFactory = i0.ɵɵgetInheritedFactory(PackageLocationStrategy)))(__ngFactoryType__ || PackageLocationStrategy); }; })();
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: PackageLocationStrategy, factory: PackageLocationStrategy.ɵfac });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PackageLocationStrategy, [{
        type: Injectable
    }], null, null); })();

/** Feeds every new Screen context into the PackageLocationStrategy and starts the Router once. */
class PackageRouterBridge {
    strategy = inject(LocationStrategy);
    router = inject(Router);
    injector = inject(Injector);
    started = false;
    connect(context) {
        if (!(this.strategy instanceof PackageLocationStrategy)) {
            throw new Error('providePackageRouter was not used: LocationStrategy is not a PackageLocationStrategy');
        }
        const strategy = this.strategy;
        return effect(() => {
            strategy.applyContext(context());
            if (!this.started) {
                this.started = true;
                this.router.initialNavigation();
            }
        }, { injector: this.injector });
    }
    static ɵfac = function PackageRouterBridge_Factory(__ngFactoryType__) { return new (__ngFactoryType__ || PackageRouterBridge)(); };
    static ɵprov = /*@__PURE__*/ i0.ɵɵdefineInjectable({ token: PackageRouterBridge, factory: PackageRouterBridge.ɵfac });
}
(() => { (typeof ngDevMode === "undefined" || ngDevMode) && i0.ɵsetClassMetadata(PackageRouterBridge, [{
        type: Injectable
    }], null, null); })();
/** provideRouter plus the Console-backed LocationStrategy and the bridge. */
function providePackageRouter(routes, ...features) {
    return [
        provideRouter(routes, ...features),
        { provide: LocationStrategy, useClass: PackageLocationStrategy },
        PackageRouterBridge,
    ];
}

/** Reads the CSP nonce of the host document: `[ngCspNonce]` attribute first, then `meta[name="csp-nonce"]`. */
function readHostNonce(doc) {
    const fromAttribute = doc.querySelector('[ngCspNonce]')?.getAttribute('ngCspNonce');
    if (fromAttribute) {
        return fromAttribute;
    }
    const fromMeta = doc.querySelector('meta[name="csp-nonce"]')?.getAttribute('content');
    return fromMeta === '' ? null : (fromMeta ?? null);
}

/** Contract 4.4: the Console toggles this class on <html>. */
const HOST_DARK_MODE_SELECTOR = '.p-dark';
function packageLayerName(packageName) {
    elementPrefix(packageName);
    return `primeng-dp-${packageName}`;
}
function resolveNonce(options) {
    return options.nonce ?? readHostNonce(options.document ?? document) ?? undefined;
}
/** Styled config: Aura preset with a package-specific CSS layer. */
function buildPrimeNgConfig(options) {
    const layer = packageLayerName(options.packageName);
    return {
        ripple: options.ripple ?? false,
        csp: { nonce: resolveNonce(options) },
        theme: {
            preset: Aura,
            options: {
                darkModeSelector: HOST_DARK_MODE_SELECTOR,
                cssLayer: { name: layer, order: `theme, base, primeng, ${layer}` },
            },
        },
    };
}
/** Config without a preset: the package inherits the Console theme. */
function buildInheritedPrimeNgConfig(options) {
    packageLayerName(options.packageName);
    return { ripple: options.ripple ?? false, csp: { nonce: resolveNonce(options) }, theme: 'none' };
}
function providePackagePrimeNG(options) {
    return providePrimeNG(buildPrimeNgConfig(options));
}
function providePackagePrimeNGInheritingConsoleTheme(options) {
    return providePrimeNG(buildInheritedPrimeNgConfig(options));
}
function providePackageCspNonce(options = {}) {
    return {
        provide: CSP_NONCE,
        useFactory: () => options.nonce ?? readHostNonce(inject(DOCUMENT)),
    };
}
/** Applies `context.cspNonce` once the context exists (block 07). */
function applyContextNonce(primeng, nonce) {
    if (nonce !== '' && primeng.csp().nonce !== nonce) {
        primeng.csp.set({ nonce });
    }
}

/**
 * Call in the constructor of a Screen root component: connects the router bridge (when
 * `providePackageRouter` was used) and keeps PrimeNG's nonce equal to `context().cspNonce`.
 */
function connectPackageScreen(context) {
    inject(PackageRouterBridge, { optional: true })?.connect(context);
    const primeng = inject(PrimeNG, { optional: true });
    if (primeng !== null) {
        effect(() => {
            applyContextNonce(primeng, context().cspNonce);
        });
    }
}

class EmptyScreenMapError extends Error {
    packageName;
    constructor(packageName) {
        super(`definePackageScreens('${packageName}') needs at least one screen`);
        this.packageName = packageName;
        this.name = 'EmptyScreenMapError';
    }
}
class PackageAlreadyDefinedError extends Error {
    packageName;
    constructor(packageName) {
        super(`Package "${packageName}" was already defined in this page`);
        this.packageName = packageName;
        this.name = 'PackageAlreadyDefinedError';
    }
}
class ElementAlreadyDefinedError extends Error {
    tag;
    constructor(tag) {
        super(`Custom element "${tag}" is already defined (another runtime or version owns it); reload the page`);
        this.tag = tag;
        this.name = 'ElementAlreadyDefinedError';
    }
}
const PACKAGE_NAME = new InjectionToken('PACKAGE_NAME');
function injectPackageName() {
    return inject(PACKAGE_NAME);
}
function browserDependencies() {
    return {
        createApplication: (config) => createApplication(config),
        createCustomElement: (component, config) => createCustomElement(component, config),
        registry: customElements,
        document,
    };
}
/** Boots one zoneless Angular application per package and defines its screens as custom elements. */
class PackageScreenRegistrar {
    dependencies;
    definedPackages = new Set();
    constructor(dependencies) {
        this.dependencies = dependencies;
    }
    async define(packageName, screens, options = {}) {
        elementPrefix(packageName);
        const entries = Object.entries(screens);
        if (entries.length === 0) {
            throw new EmptyScreenMapError(packageName);
        }
        for (const [tag] of entries) {
            assertPackageElementTag(packageName, tag);
        }
        if (this.definedPackages.has(packageName)) {
            throw new PackageAlreadyDefinedError(packageName);
        }
        for (const [tag] of entries) {
            if (this.dependencies.registry.get(tag) !== undefined) {
                throw new ElementAlreadyDefinedError(tag);
            }
        }
        // Reserved before the first await so a concurrent call fails too.
        this.definedPackages.add(packageName);
        let application;
        try {
            application = await this.dependencies.createApplication({
                providers: [
                    provideZonelessChangeDetection(),
                    { provide: APP_ID, useValue: `dp-${packageName}` },
                    providePackageCspNonce(options.nonce === undefined ? {} : { nonce: options.nonce }),
                    { provide: PACKAGE_NAME, useValue: packageName },
                    ...(options.providers ?? []),
                ],
            });
        }
        catch (error) {
            this.definedPackages.delete(packageName);
            throw error;
        }
        for (const [tag, component] of entries) {
            this.dependencies.registry.define(tag, this.dependencies.createCustomElement(component, { injector: application.injector }));
        }
    }
}
let defaultRegistrar;
function definePackageScreens(packageName, screens, options) {
    defaultRegistrar ??= new PackageScreenRegistrar(browserDependencies());
    return defaultRegistrar.define(packageName, screens, options);
}

/**
 * Generated bundle index. Do not edit.
 */

export { AssetsUnavailableError, ElementAlreadyDefinedError, EmptyScreenMapError, MissingPackageContextError, PACKAGE_CONTEXT, PACKAGE_NAME, PackageAlreadyDefinedError, PackageContextNotConnectedError, PackageLocationStrategy, PackageRouterBridge, connectPackageScreen, definePackageScreens, injectPackageAssets, injectPackageContext, injectPackageName, providePackageContext, providePackageCspNonce, providePackagePrimeNG, providePackagePrimeNGInheritingConsoleTheme, providePackageRouter };
//# sourceMappingURL=olx-package-ui-sdk.mjs.map
