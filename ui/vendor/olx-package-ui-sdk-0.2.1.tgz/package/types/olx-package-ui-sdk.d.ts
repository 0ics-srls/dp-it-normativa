import * as i0 from '@angular/core';
import { InjectionToken, Signal, Type, Provider, EnvironmentProviders, EffectRef } from '@angular/core';
import { PackageScreenContext, PackageAssets } from '@olx/package-ui-sdk/contract';
export { AssetPathError, HostUiApiVersion, InvalidElementTagError, InvalidPackageNameError, LocalizedText, NotifyLevel, PackageAssets, PackageLocale, PackageMenuDescriptor, PackageScreenContext, PackageScreenDescriptor, PackageScreenTools, PackageTheme, PackageUiDescriptor, QueryParams, assertAssetPath, elementPrefix } from '@olx/package-ui-sdk/contract';
import { LocationStrategy, LocationChangeListener } from '@angular/common';
import { Routes, RouterFeatures } from '@angular/router';

declare const PACKAGE_CONTEXT: InjectionToken<Signal<PackageScreenContext>>;
/** The shape a Screen's root component must have: contract 4.2, `context = input.required<PackageScreenContext>()`. */
interface PackageScreenHost {
    readonly context: Signal<PackageScreenContext>;
}
declare class MissingPackageContextError extends Error {
    constructor();
}
/** Provides the context signal of `host` (the Screen root component) to its descendants. */
declare function providePackageContext(host: Type<PackageScreenHost>): Provider;
declare function injectPackageContext(): Signal<PackageScreenContext>;

declare class AssetsUnavailableError extends Error {
    constructor(hostUiApi: string);
}
/** The assets of the current Screen context; fails clearly on a Host that predates contract v0.4. */
declare function injectPackageAssets(): PackageAssets;

/**
 * Call in the constructor of a Screen root component: connects the router bridge (when
 * `providePackageRouter` was used) and keeps PrimeNG's nonce equal to `context().cspNonce`.
 */
declare function connectPackageScreen(context: Signal<PackageScreenContext>): void;

declare class EmptyScreenMapError extends Error {
    readonly packageName: string;
    constructor(packageName: string);
}
declare class PackageAlreadyDefinedError extends Error {
    readonly packageName: string;
    constructor(packageName: string);
}
declare class ElementAlreadyDefinedError extends Error {
    readonly tag: string;
    constructor(tag: string);
}
declare const PACKAGE_NAME: InjectionToken<string>;
declare function injectPackageName(): string;
type ScreenMap = Readonly<Record<string, Type<unknown>>>;
interface DefinePackageScreensOptions {
    readonly providers?: readonly (Provider | EnvironmentProviders)[];
    readonly nonce?: string | null;
}
declare function definePackageScreens(packageName: string, screens: ScreenMap, options?: DefinePackageScreensOptions): Promise<void>;

declare class PackageContextNotConnectedError extends Error {
    constructor();
}
/**
 * Angular LocationStrategy that keeps the Router's URL in the Console-provided context
 * (`subPath`/`query`) and reports navigations through `context.navigate`.
 */
declare class PackageLocationStrategy extends LocationStrategy {
    private ref;
    private navigator;
    private current;
    private readonly listeners;
    /** Stores the latest context; returns true (and notifies listeners) when the location changed. */
    applyContext(context: PackageScreenContext): boolean;
    path(): string;
    prepareExternalUrl(internal: string): string;
    pushState(_state: unknown, _title: string, url: string, queryParams: string): void;
    replaceState(_state: unknown, _title: string, url: string, queryParams: string): void;
    onPopState(fn: LocationChangeListener): VoidFunction;
    getBaseHref(): string;
    getState(): unknown;
    back(): void;
    forward(): void;
    historyGo(relativePosition?: number): void;
    private go;
    static ɵfac: i0.ɵɵFactoryDeclaration<PackageLocationStrategy, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PackageLocationStrategy>;
}

/** Feeds every new Screen context into the PackageLocationStrategy and starts the Router once. */
declare class PackageRouterBridge {
    private readonly strategy;
    private readonly router;
    private readonly injector;
    private started;
    connect(context: Signal<PackageScreenContext>): EffectRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<PackageRouterBridge, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<PackageRouterBridge>;
}
/** provideRouter plus the Console-backed LocationStrategy and the bridge. */
declare function providePackageRouter(routes: Routes, ...features: RouterFeatures[]): (Provider | EnvironmentProviders)[];

interface PackagePrimeNgOptions {
    readonly packageName: string;
    readonly nonce?: string | null;
    readonly ripple?: boolean;
    readonly document?: Document;
}
declare function providePackagePrimeNG(options: PackagePrimeNgOptions): EnvironmentProviders;
declare function providePackagePrimeNGInheritingConsoleTheme(options: PackagePrimeNgOptions): EnvironmentProviders;
declare function providePackageCspNonce(options?: {
    readonly nonce?: string | null;
}): Provider;

export { AssetsUnavailableError, ElementAlreadyDefinedError, EmptyScreenMapError, MissingPackageContextError, PACKAGE_CONTEXT, PACKAGE_NAME, PackageAlreadyDefinedError, PackageContextNotConnectedError, PackageLocationStrategy, PackageRouterBridge, connectPackageScreen, definePackageScreens, injectPackageAssets, injectPackageContext, injectPackageName, providePackageContext, providePackageCspNonce, providePackagePrimeNG, providePackagePrimeNGInheritingConsoleTheme, providePackageRouter };
export type { DefinePackageScreensOptions, PackagePrimeNgOptions, PackageScreenHost, ScreenMap };
//# sourceMappingURL=olx-package-ui-sdk.d.ts.map
